function inline_tweet_sharer_open_win(url)
{
window.open(url,'tweetwindow','width=566,height=592,location=yes,directories=no,channelmode=no,menubar=no,resizable=no,scrollbars=no,status=no,toolbar=no');
return false;
}